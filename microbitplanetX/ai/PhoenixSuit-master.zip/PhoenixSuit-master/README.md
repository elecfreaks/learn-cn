# PhoenixSuit v1.10
Firmware flashing tool for Allwinner Soc chip under Windows
